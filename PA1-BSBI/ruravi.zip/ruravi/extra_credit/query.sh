#!/bin/bash
python query.py $1
