#!/usr/bin/env sh

# ./corrector.sh <dev | test> <uniform | emperical> <queries file>

python corrector.py $1 $2 $3
